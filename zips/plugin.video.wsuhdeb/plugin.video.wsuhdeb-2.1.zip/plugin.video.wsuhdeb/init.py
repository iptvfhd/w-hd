import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,datetime,os,json,base64,plugintools
import xml.etree.ElementTree as ElementTree
reload(sys)
sys.setdefaultencoding('utf8')
SKIN_VIEW_FOR_MOVIES="515"
addonDir = plugintools.get_runtime_path()
global kontroll
background = "YmFja2dyb3VuZC5wbmc="
defaultlogo = "ZGVmYXVsdGxvZ28ucG5n"
hometheater = "aG9tZXRoZWF0ZXIuanBn"
noposter = "bm9wb3N0ZXIuanBn"
theater = "dGhlYXRlci5qcGc="
addonxml = "YWRkb24ueG1s"
addonpy = "ZGVmYXVsdC5weQ=="
icon = "aWNvbi5wbmc="
fanart = "ZmFuYXJ0LnBuZw=="
message = "TyBNYWkgR290IDp2"
def run():
    global pnimi
    global televisioonilink
    global serieslink
    global filmilink
    global andmelink
    global uuenduslink
    global base_url
    global LOAD_LIVE
    global uuendused
    global vanemalukk
    global version
    global usehls
    global portnum
    global usrname
    global pword
    version = 1
    usrname=plugintools.get_setting("kasutajanimi")
    pword=plugintools.get_setting("salasona")
    base_url="http://w-suhd.com"
    portnum="8000"
    usehls=plugintools.get_setting("usehls")
    uuendused=plugintools.get_setting("uuendused")
    vanemalukk=plugintools.get_setting("vanemalukk")
    pnimi = "W-SUHD "
    LOAD_LIVE = os.path.join( plugintools.get_runtime_path() , "resources" , "art" )
    plugintools.log(pnimi+"Iniciando")
    televisioonilink = "%s:%s/enigma2.php?username=%s&password=%s&type=get_live_categories"%(base_url,portnum,usrname,pword)
    serieslink = "%s:%s/player_api.php?username=%s&password=%s&action=get_series_categories"%(base_url,portnum,usrname,pword)
    filmilink = "%s:%s/enigma2.php?username=%s&password=%s&type=get_vod_categories"%(base_url,portnum,usrname,pword)
    andmelink = "%s:%s/panel_api.php?username=%s&password=%s"%(base_url,portnum,usrname,pword)
    params = plugintools.get_params()
    
    if params.get("action") is None:
        peamenyy(params)
    else:
        action = params.get("action")
        exec action+"(params)"

    plugintools.close_item_list()
def peamenyy(params):
    plugintools.log(pnimi+b64dec("TWVuw7ogUHJpbmNpcGFs")+repr(params))
    load_channels()
    if not base_url:
       plugintools.open_settings_dialog()
    channels = kontroll()
    if channels == 1:
       plugintools.log(pnimi+b64dec("U2VzacOzbiBpbmljaWFkYSBjb24gZXhpdG8="))
       plugintools.add_item( action="execute_ainfo",   title="Mi cuenta" , thumbnail="" , fanart=os.path.join(LOAD_LIVE,"background.png") , folder=True )
       plugintools.add_item( action="security_check",  title="TV en Vivo" , thumbnail="" , fanart=os.path.join(LOAD_LIVE,"background.png") , folder=True )
       plugintools.add_item( action="tvshows",  title="Series de TV" , thumbnail="" , fanart=os.path.join(LOAD_LIVE,"background.png") , folder=True )
       plugintools.add_item( action="detect_modification",   title="Video por demanda" , thumbnail="" , fanart=os.path.join(LOAD_LIVE,"background.png") , folder=True )
       plugintools.add_item( action="settingsmenu", title="Ajustes" , thumbnail="" , fanart=os.path.join(LOAD_LIVE,"background.png" ), folder=False )
       plugintools.set_view( plugintools.LIST )
    else:
       plugintools.log(pnimi+b64dec("RmFsbG8gYWwgaW5pY2lhciBzZXNpw7Nu"))
       plugintools.message(b64dec("RmFsbG8gYWwgaW5pY2lhciBzZXNpw7Nu"), b64dec("UmF6b25lcyBwb3NpYmxlczogVXN1YXJpbyBvIGNvbnRyYXNlw7FhIGluY29ycmVjdG9zLiDCoUFzZWfDunJhdGUgZGUgaGFiZXIgaW5ncmVzYWRvIGxvcyBkYXRvcyBjb3JyZWN0b3MhIFBhcmEgbcOhcyBpbmZvcm1hY2nDs24sIGNvbXVuw61jYXRlIGNvbiB0dSB2ZW5kZWRvci4=")%(pnimi))
       exit()  
    if plugintools.get_setting("improve")=="true":
        tseaded = xbmc.translatePath("special://userdata/advancedsettings.xml")
        if not os.path.exists(tseaded):
            file = open( os.path.join(plugintools.get_runtime_path(),"resources","advancedsettings.xml") )
            data = file.read()
            file.close()
            file = open(tseaded,"w")
            file.write(data)
            file.close()
            plugintools.message(pnimi, "Nuevos ajustes de streaming avanzado agregados.")
def settingsmenu(params):
    plugintools.log(pnimi+b64dec("TWVuw7ogZGUgYWp1dGVz")+repr(params))
    plugintools.open_settings_dialog()
def security_check(params):
    plugintools.log(pnimi+b64dec("TWVuw7ogZGUgY24uIGVuIHZpdm8=")+repr(params))
    request = urllib2.Request(televisioonilink, headers={"Accept" : "application/xml"})
    u = urllib2.urlopen(request)
    tree = ElementTree.parse(u)
    rootElem = tree.getroot()
    for channel in tree.findall("channel"):
        kanalinimi = channel.find("title").text
        kanalinimi = base64.b64decode(kanalinimi)
        kategoorialink = channel.find("playlist_url").text
        plugintools.add_item( action="stream_video", title=kanalinimi , url=kategoorialink , thumbnail=os.path.join(LOAD_LIVE,"logo.png") , fanart="" , folder=True )
    plugintools.set_view( plugintools.LIST )
def tvshows(params):
    request = urllib2.Request(serieslink)
    u = urllib2.urlopen(request)
    conts = json.load(u)
    for cats in conts:
        kanalinimi = cats["category_name"]
        kategoorialink = cats["category_id"]
        plugintools.add_item( action="tvs_stage1", title=kanalinimi , url=kategoorialink , thumbnail=os.path.join(LOAD_LIVE,"logo.png") , fanart="" , folder=True )
    plugintools.set_view( plugintools.LIST )
def tvs_stage1(params):
        purl = "%s:%s/player_api.php?username=%s&password=%s&action=get_series&category_id=%s"%(base_url,portnum,usrname,pword,params.get("url"))
        request = urllib2.Request(purl)
        u = urllib2.urlopen(request)
        conts = json.load(u)
        for channel in conts:
            pealkiri = channel["name"].encode('utf-8')
            striimilink = str(channel["series_id"])
            pilt = channel["cover"]
            kirjeldus = channel["plot"].encode('utf-8')
            if pilt:
               plugintools.add_item( action="tvs_stage2", title=pealkiri , url=striimilink, thumbnail=pilt, plot=kirjeldus, fanart=os.path.join(LOAD_LIVE,"theater.jpg") , extra="", folder=True )
            else:
               plugintools.add_item( action="tvs_stage2", title=pealkiri , url=striimilink, thumbnail=os.path.join(LOAD_LIVE,"noposter.jpg"), plot=kirjeldus, fanart="" , extra="", folder=True )
        plugintools.set_view( plugintools.MOVIES )
        xbmc.executebuiltin('Container.SetViewMode(515)')
def tvs_stage2(params):
        purl = "%s:%s/player_api.php?username=%s&password=%s&action=get_series_info&series_id=%s"%(base_url,portnum,usrname,pword,params.get("url"))
        request = urllib2.Request(purl)
        u = urllib2.urlopen(request)
        conts = json.load(u)
        conts = conts["episodes"]
        for conts2 in conts:
			conts2 = conts[conts2]
			i = 0
			for channel in conts2:
				i = i+1
				pealkiri = str(channel["season"])+"x"+"%02d"%(i)+": "+channel["title"].encode('utf-8')
				striimilink = "%s:%s/series/%s/%s/%s.%s"%(base_url,portnum,usrname,pword,channel["id"],channel["container_extension"])
				pilt = channel["info"]["movie_image"]
				kirjeldus = channel["info"]["plot"].encode('utf-8')
				if pilt:
				   plugintools.add_item( action="restart_service", title=pealkiri , url=striimilink, thumbnail=pilt, plot=kirjeldus, fanart=pilt.replace("small", "big") , extra="", isPlayable=True, folder=False )
				else:
				   plugintools.add_item( action="restart_service", title=pealkiri , url=striimilink, thumbnail=os.path.join(LOAD_LIVE,"noposter.jpg"), plot=kirjeldus, fanart="" , extra="", isPlayable=True, folder=False )
        plugintools.set_view( plugintools.MOVIES )
        xbmc.executebuiltin('Container.SetViewMode(515)')
def detect_modification(params):
    plugintools.log(pnimi+b64dec("TWVuw7ogVk9EIA==")+repr(params))        
    request = urllib2.Request(filmilink, headers={"Accept" : "application/xml"})
    u = urllib2.urlopen(request)
    tree = ElementTree.parse(u)
    rootElem = tree.getroot()
    for channel in tree.findall("channel"):
        filminimi = channel.find("title").text
        filminimi = base64.b64decode(filminimi)
        kategoorialink = channel.find("playlist_url").text
        plugintools.add_item( action="get_myaccount", title=filminimi , url=kategoorialink , thumbnail = "" , fanart=os.path.join(LOAD_LIVE,"theater.jpg") , folder=True )
    plugintools.set_view( plugintools.LIST )
def stream_video(params):
    plugintools.log(pnimi+b64dec("TWVuw7ogZGUgY2FuYWxlcyBlbiB2aXZv")+repr(params))
    if vanemalukk == "true":
       pealkiri = params.get("title")
       vanema_lukk(pealkiri)
    url = params.get("url")
    request = urllib2.Request(url, headers={"Accept" : "application/xml"})
    u = urllib2.urlopen(request)
    tree = ElementTree.parse(u)
    rootElem = tree.getroot()
    for channel in tree.findall("channel"):
        kanalinimi = channel.find("title").text
        kanalinimi = base64.b64decode(kanalinimi)
        kanalinimi = kanalinimi.partition("[")
        striimilink = channel.find("stream_url").text
        if usehls == "true":
           striimilink = striimilink.replace(".ts", ".m3u8")
        pilt = channel.find("desc_image").text
        kava = kanalinimi[1]+kanalinimi[2]
        kava = kava.partition("]")
        kava = kava[2]
        kava = kava.partition("   ")
        kava = kava[2]
        shou = "[COLOR white]%s [/COLOR]"%(kanalinimi[0])+kava
        kirjeldus = channel.find("description").text
        if kirjeldus:
           kirjeldus = base64.b64decode(kirjeldus)
           nyyd = kirjeldus.partition("(")
           nyyd = "AHORA: " +nyyd[0]
           jargmine = kirjeldus.partition(")\n")
           jargmine = jargmine[2].partition("(")
           jargmine = "SIGUE: " +jargmine[0]
           kokku = nyyd+jargmine
        else:
           kokku = ""
        if pilt:
           plugintools.add_item( action="run_cronjob", title=shou , url=striimilink, thumbnail=pilt, plot=kokku, fanart=os.path.join(LOAD_LIVE,"hometheater.jpg"), extra="", isPlayable=True, folder=False )
        else:
           plugintools.add_item( action="run_cronjob", title=shou , url=striimilink, thumbnail=os.path.join(LOAD_LIVE,"defaultlogo.png") , plot=kokku, fanart=os.path.join(LOAD_LIVE,"hometheater.jpg") , extra="", isPlayable=True, folder=False )
    plugintools.set_view( plugintools.EPISODES )
    xbmc.executebuiltin("Container.SetViewMode(503)")
def get_myaccount(params):
        plugintools.log(pnimi+b64dec("TWVuw7ogZGUgY2FuYWxlcyBWT0Q=")+repr(params))
        if vanemalukk == "true":
           pealkiri = params.get("title")
           vanema_lukk(pealkiri)
        purl = params.get("url")
        request = urllib2.Request(purl, headers={"Accept" : "application/xml"})
        u = urllib2.urlopen(request)
        tree = ElementTree.parse(u)
        rootElem = tree.getroot()
        for channel in tree.findall("channel"):
            pealkiri = channel.find("title").text
            pealkiri = base64.b64decode(pealkiri)
            pealkiri = pealkiri.encode("utf-8")
            striimilink = channel.find("stream_url").text
            pilt = channel.find("desc_image").text 
            kirjeldus = channel.find("description").text
            if kirjeldus:
               kirjeldus = base64.b64decode(kirjeldus) 
            if pilt:
               plugintools.add_item( action="restart_service", title=pealkiri , url=striimilink, thumbnail=pilt, plot=kirjeldus, fanart=os.path.join(LOAD_LIVE,"theater.jpg") , extra="", isPlayable=True, folder=False )
            else:
               plugintools.add_item( action="restart_service", title=pealkiri , url=striimilink, thumbnail=os.path.join(LOAD_LIVE,"noposter.jpg"), plot=kirjeldus, fanart="" , extra="", isPlayable=True, folder=False )
        plugintools.set_view( plugintools.MOVIES )
        xbmc.executebuiltin('Container.SetViewMode(515)')
def run_cronjob(params):
    plugintools.log(pnimi+"PLAY_LIVE"+repr(params))
    if vanemalukk == "true":
       pealkiri = params.get("title")
       vanema_lukk(pealkiri)
    lopplink = params.get("url")
    plugintools.play_resolved_url( lopplink )
def restart_service(params):
    plugintools.log(pnimi+"REPR VOD"+repr(params))
    if vanemalukk == "true":
       pealkiri = params.get("title")
       vanema_lukk(pealkiri)
    lopplink = params.get("url")
    plugintools.play_resolved_url( lopplink )
def grab_epg():
    req = urllib2.Request(andmelink)
    response = urllib2.urlopen(req)
    link=response.read()
    jdata = json.loads(link.decode('utf8'))
    response.close()
    if jdata:
       plugintools.log(pnimi+"datos cargados ")
       return jdata
def kontroll():
    randomstring = grab_epg()
    kasutajainfo = randomstring["user_info"]
    kontroll = kasutajainfo["auth"]
    return kontroll
def b64dec(strng):
    fin1 = base64.b64decode(strng)
    return fin1
def execute_ainfo(params):
    plugintools.log(pnimi+b64dec("TWVuw7ogZGUgTWkgQ3VlbnRh")+repr(params))
    andmed = grab_epg()
    kasutajaAndmed = andmed["user_info"]
    seis = kasutajaAndmed["status"]
    aegub = kasutajaAndmed["exp_date"]
    if aegub:
       aegub = datetime.datetime.fromtimestamp(int(aegub)).strftime('%H:%M %d.%m.%Y')
    else:
       aegub = "Nunca" 
    trialacc = kasutajaAndmed["is_trial"]
    if trialacc == "0":
       trialacc = "No"
    else:
       trialacc = b64dec("U8Ot")
    connnum = kasutajaAndmed["max_connections"]
    if connnum == "0":
       connnum = "Ilimitadas"
    polarbears = kasutajaAndmed["username"]
    plugintools.add_item( action="",   title="[COLOR = white]Usuario: [/COLOR]"+polarbears , thumbnail="" , fanart=os.path.join(LOAD_LIVE,"background.png") , folder=False )
    plugintools.add_item( action="",   title="[COLOR = white]Estado: [/COLOR]"+seis , thumbnail="" , fanart=os.path.join(LOAD_LIVE,"background.png") , folder=False )
    plugintools.add_item( action="",   title="[COLOR = white]Expira: [/COLOR]"+aegub , thumbnail="" , fanart=os.path.join(LOAD_LIVE,"background.png") , folder=False )
    plugintools.add_item( action="",   title="[COLOR = white]Cuenta de prueba: [/COLOR]"+trialacc , thumbnail="" , fanart=os.path.join(LOAD_LIVE,"background.png") , folder=False )
    plugintools.add_item( action="",   title=b64dec("W0NPTE9SID0gd2hpdGVdTsO6bS4gZGUgQ29uZXhpb25lczogWy9DT0xPUl0=")+connnum , thumbnail="" , fanart=os.path.join(LOAD_LIVE,"background.png") , folder=False )
    plugintools.set_view( plugintools.LIST )
def vanema_lukk(name):
        plugintools.log(pnimi+b64dec("QmxvcXVlbyBwYXJlbnRhbA=="))
        a = 'For adults', 'adult'
        if any(s in name for s in a):
           xbmc.executebuiltin((u'XBMC.Notification("Control parental", "Canales que pueden tener contenido adulto", 2000)'))
           text = plugintools.keyboard_input(default_text="", title="Control parental")
           if text==plugintools.get_setting("vanemakood"):
              return
           else:
              exit()
        else:
           name = ""
def kontrolli_uuendusi():
	bleh1 =""

def DownloaderClass(url,dest):
    dp = xbmcgui.DialogProgress()
    dp.create("Getting update","Downloading")
    urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))
def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        print percent
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if dp.iscanceled(): 
        print "DOWNLOAD CANCELLED" # need to get this part working
        dp.close()
def load_channels():
    statinfo = os.stat(LOAD_LIVE+"/background.png")
    statinfo = os.stat(LOAD_LIVE+"/defaultlogo.png")
    statinfo = os.stat(LOAD_LIVE+"/hometheater.jpg")
    statinfo = os.stat(LOAD_LIVE+"/noposter.jpg")
    statinfo = os.stat(LOAD_LIVE+"/theater.jpg")
    statinfo = os.stat(addonDir+"/addon.xml")
    statinfo = os.stat(addonDir+"/init.py")
    statinfo = os.stat(addonDir+"/icon.png")
    statinfo = os.stat(addonDir+"/fanart.png")
run()